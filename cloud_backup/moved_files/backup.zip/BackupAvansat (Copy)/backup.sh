#!/bin/bash

# Variabile și constante
LOG_FILE="out.log"
DEBUG_MODE="off"
CLOUD_REPO="git@github.com:11VladC12/BackupAvansat.git"
CLOUD_DIR="cloud_backup"
BACKUP_DIR="./backup"
CLEANUP_PATH="./my_files" # Directorul default de unde se face backupul
RUN_ON_SCHEDULE=false     # Dacă este true, rulat automat (Luni 20:00); dacă false, rulează imediat după opțiunea 4

# Debugging
log_debug() {
    [[ "$DEBUG_MODE" == "on" ]] && echo "[DEBUG] $1"
}

# Activare mod debug (setarea fluxurilor de log)
setup_debug() {
    if [[ "$DEBUG_MODE" == "on" ]]; then
        exec > >(tee -a "$LOG_FILE") 2>&1
        echo "[DEBUG] Modul de debug este activat. Logurile vor fi salvate în $LOG_FILE."
    fi
}

# Afisare help/usage
show_help() {
    echo "========================================="
    echo "            Advanced Backup Tool         "
    echo "========================================="
    echo "Comenzi disponibile:"
    echo "  $0 [optiuni]"
    echo "Optiuni:"
    echo "  -h, --help            Afiseaza acest mesaj de ajutor"
    echo "  --debug=on|off        Activeaza sau dezactiveaza modul de debug (implicit: off)"
    echo "Functionalitati interactive:"
    echo "  1. Gaseste fisiere mai vechi decat o anumita data"
    echo "  2. Muta fisiere local sau in cloud"
    echo "  3. Sincronizeaza log-urile cu cloud-ul"
    echo "  4. Programeaza sau ruleaza imediat curatarea"
    echo "  5. Iesire"
    echo "========================================="
    echo "Exemple utilizare:"
    echo "  1. Ruleaza scriptul normal: ./backup.sh"
    echo "  2. Activeaza debug: ./backup.sh --debug=on"
    echo "  3. Afiseaza ajutor: ./backup.sh --help"
    echo "========================================="
}

# Afisare meniu pentru utilizator
print_menu() {
    echo "==============================="
    echo "     Advanced File Backup Tool "
    echo "==============================="
    echo "Alege o opțiune:"
    echo "  1. Găsește fișiere mai vechi decât o anumită dată"
    echo "  2. Mută fișiere local sau în cloud"
    echo "  3. Șterge fișiere din backup"
    echo "  4. Sincronizează log-urile cu cloud-ul"
    echo "  5. Programează sau rulează imediat curățarea"
    echo "  6. Ieșire"
    echo "==============================="
    echo -n "Alegerea ta: "
}


# Mesaj de eroare 
error_message() {
    echo "[EROARE] Alegerea nu este valida. Te rog sa incerci din nou."
}

# Mesaj de confirmare
confirmation_message() {
    echo "[INFO] Actiunea a fost realizata cu succes!"
}

# Find and List Old Files
find_old_files() {
    echo "Introdu o data sau o durata (ex.: 2023-01-01 sau 1d):"
    read -r input_date
    parsed_input=$(parse_date_input "$input_date")
    echo "Caut fisiere mai vechi de $input_date..."
    find "$BACKUP_DIR" -type f $parsed_input | tee -a "$LOG_FILE"
}

# Parse and Process Input Date/Duration
parse_date_input() {
    local input_date="$1"
    regex_date='^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
    regex_duration='^([0-9]+)([dmyw])$'

    if [[ $input_date =~ $regex_date ]]; then
        echo "-not -newermt ${input_date}"
    elif [[ $input_date =~ $regex_duration ]]; then
        local num="${BASH_REMATCH[1]}"
        local unit="${BASH_REMATCH[2]}"
        case "$unit" in
            d) echo "-mtime +$num" ;;
            w) echo "-mtime +$((num * 7))" ;;
            m) echo "-mtime +$((num * 30))" ;;
            y) echo "-mtime +$((num * 365))" ;;
            *) echo "Unitate invalida"; exit 1 ;;
        esac
    else
        echo "Format invalid pentru input!"
        exit 1
    fi
}
move_files() {
    local source_dir="./my_files"

    echo "Fișiere disponibile în $source_dir:"
    local files=()
    local index=1

    # Enumerăm fișierele disponibile
    while IFS= read -r file; do
        files+=("$file")
        echo "$index. $file"
        ((index++))
    done < <(ls -p "$source_dir" | grep -v /)

    if [[ ${#files[@]} -eq 0 ]]; then
        echo "Nu există fișiere disponibile în $source_dir."
        return
    fi

    echo "Introdu numerele fișierelor de mutat, separate prin spații (ex.: 1 3 5):"
    read -r selected_indices

    for index in $selected_indices; do
        # Verificăm dacă indexul este valid
        if ((index > 0 && index <= ${#files[@]})); then
            file="${files[index-1]}"
            echo "Muta fișierul $file în:
1. Director local de backup
2. Backup în cloud"
            echo -n "Alege o opțiune (1/2): "
            read -r location_choice

            if [[ "$location_choice" == "1" ]]; then
                mv "$source_dir/$file" "$BACKUP_DIR" && echo "Fișierul $file a fost mutat în $BACKUP_DIR"
            elif [[ "$location_choice" == "2" ]]; then
                prepare_cloud
                cloud_target="$CLOUD_DIR/moved_files"
                mkdir -p "$cloud_target"
                cp "$source_dir/$file" "$cloud_target" && echo "Fișierul $file a fost copiat în directorul cloud: $cloud_target"
                sync_to_cloud
            else
                echo "Opțiune invalidă. Nu s-a efectuat nicio acțiune pentru $file."
            fi
        else
            echo "Index invalid: $index. Sar peste."
        fi
    done
}
# Funcție pentru a șterge fișiere din folderul ./backup
delete_files() {
    echo "Fișiere disponibile în $BACKUP_DIR:"
    local files=()
    local index=1

    # Enumerăm fișierele din directorul de backup
    while IFS= read -r file; do
        files+=("$file")
        echo "$index. $file"
        ((index++))
    done < <(ls -p "$BACKUP_DIR" | grep -v /)

    if [[ ${#files[@]} -eq 0 ]]; then
        echo "Nu există fișiere disponibile în $BACKUP_DIR."
        return
    fi

    echo "Introdu numerele fișierelor de șters, separate prin spații (ex.: 1 3 5):"
    read -r selected_indices

    for index in $selected_indices; do
        # Verificăm dacă indexul este valid
        if ((index > 0 && index <= ${#files[@]})); then
            file="${files[index-1]}"
            echo "Șterg fișierul: $file..."
            rm -f "$BACKUP_DIR/$file" && echo "Fișierul $file a fost șters cu succes."
        else
            echo "Index invalid: $index. Sar peste."
        fi
    done
}
# Sync Logs to Cloud
sync_to_cloud() {
    echo "Sincronizez logurile cu cloud-ul..."
    prepare_cloud
    cp "$LOG_FILE" "$CLOUD_DIR/"
    cd "$CLOUD_DIR" || exit
    git add .
    git commit -m "Sync: $(date)" && git push || echo "Sincronizarea cu cloud-ul a esuat!"
    cd - || exit
}

# Prepare Cloud Directory
prepare_cloud() {
    if [[ ! -d "$CLOUD_DIR" ]]; then
        git clone "$CLOUD_REPO" "$CLOUD_DIR" || { echo "Clonarea repository-ului cloud a esuat!"; exit 1; }
    fi
}
# Schedule Cleanup
schedule_cleanup() {
    if [[ "$RUN_ON_SCHEDULE" == true ]]; then
        echo "Programez curățarea săptămânală..."

        echo "Vrei să redenumești fișierele mai vechi de 1 zi adăugând '.old' înaintea extensiei și să le marchezi ca depreciate? (y/n):"
        read -r rename_choice

        CRON_EXPR="46 12 * * 1"  # Ajustează la timpul dorit
        SCRIPT_PATH=$(realpath "$0")

        echo "$CRON_EXPR $SCRIPT_PATH cleanup '' '' $rename_choice" | crontab - && echo "Curățarea a fost programată cu succes!"
    else
        echo "Rulez curățarea imediat..."

        echo "Vrei să redenumești fișierele mai vechi de 1 zi adăugând '.old' înaintea extensiei și să le marchezi ca depreciate? (y/n):"
        read -r rename_choice

        perform_cleanup "" "" "$rename_choice"
    fi
}
perform_cleanup() {
    local rename_choice="$3"

    echo "Execut curățarea în directoarele/fișierele: ${TARGET_PATHS[*]}"

    for target in "${TARGET_PATHS[@]}"; do
        if [[ -d "$target" ]]; then
            find "$target" -type f -mtime +1 | while read -r file; do
                base_file=$(basename "$file")
                mv "$file" "$BACKUP_DIR/$base_file" && echo "Mutat: $base_file în $BACKUP_DIR"
                
                if [[ "$rename_choice" == "y" ]]; then
                    ext="${base_file##*.}"
                    name="${base_file%.*}"
                    renamed_file="$BACKUP_DIR/${name}.old.$ext"
                    mv "$BACKUP_DIR/$base_file" "$renamed_file" && echo "Redenumit: $renamed_file"
                    echo "#### DEPRECATED #####" >> "$renamed_file" && echo "Marcat ca depreciat: $renamed_file"
                fi
            done
        elif [[ -f "$target" ]]; then
            base_file=$(basename "$target")
            mv "$target" "$BACKUP_DIR/$base_file" && echo "Mutat: $base_file în $BACKUP_DIR"
            
            if [[ "$rename_choice" == "y" ]]; then
                ext="${base_file##*.}"
                name="${base_file%.*}"
                renamed_file="$BACKUP_DIR/${name}.old.$ext"
                mv "$BACKUP_DIR/$base_file" "$renamed_file" && echo "Redenumit: $renamed_file"
                echo "#### DEPRECATED #####" >> "$renamed_file" && echo "Marcat ca depreciat: $renamed_file"
            fi
        else
            echo "Cale invalidă: $target"
        fi
    done
}


# Procesarea argumentelor din linia de comandă
TARGET_PATHS=()

while [[ $# -gt 0 ]]; do
    case "$2" in
        -h|--help)
            show_help
            exit 0
            ;;
        --debug=*)
            DEBUG_MODE="${1#*=}"
            ;;
        *)
            TARGET_PATHS+=("$2") # Adăugăm directoarele și fișierele specificate
            ;;
    esac
    shift
done
# Configurarea modului debug
setup_debug
# Dacă nu au fost specificate căi țintă, folosește directorul default
if [[ ${#TARGET_PATHS[@]} -eq 0 ]]; then
    TARGET_PATHS=("$CLEANUP_PATH")
fi

# Funcție pentru listarea fișierelor în funcție de calea țintă
find_files_in_targets() {
    for target in "${TARGET_PATHS[@]}"; do
        if [[ -d "$target" ]]; then
            echo "Căutăm în director: $target"
            find "$target" -type f | tee -a "$LOG_FILE"
        elif [[ -f "$target" ]]; then
            echo "Fișier specificat: $target"
            echo "$target" | tee -a "$LOG_FILE"
        else
            echo "Cale invalidă: $target"
        fi
    done
}
# Actualizăm opțiunea din meniu
menu() {
    while true; do
        print_menu
        read -r choice
        case $choice in
            1) echo "Caut și gestionez fișiere vechi..."; find_old_files ;;
            2) echo "Mut fișiere..."; move_files ;;
            3) echo "Șterg fișiere din backup..."; delete_files ;;
            4) echo "Sincronizez logurile cu cloud-ul..."; sync_to_cloud ;;
            5) schedule_cleanup ;;
            6) echo "Ies..."; exit ;;
            *) echo "Opțiune invalidă. Încearcă din nou." ;;
        esac

        # Întrebare dacă utilizatorul dorește să curețe terminalul
        echo "Dorești să cureți terminalul înainte de a reveni la meniul principal? (y/n)"
        read -r clear_choice
        if [[ "$clear_choice" == "y" || "$clear_choice" == "Y" ]]; then
            clear
        fi
    done
}

# Handle Command-Line Arguments
if [[ "$1" == "-h" || "$1" == "--help" ]]; then
    show_help
    exit 0
fi

# Main execution
menu

